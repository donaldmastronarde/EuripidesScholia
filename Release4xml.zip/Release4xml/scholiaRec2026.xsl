
<xsl:stylesheet version="2.0"
     xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

 <xsl:output method="html" encoding="utf-8" version="5.0"></xsl:output>
 <xsl:include href="match-div4s2026.xsl"/>
 
 <xsl:include href="match-segs2026.xsl"/>
 <xsl:include href="match-bibl2026.xsl"/>
   
<xsl:template match="body">
<xsl:apply-templates></xsl:apply-templates></xsl:template>

 <xsl:include href="linksAndActions2026.xsl"/>
 
   

   <xsl:template match="div2"><xsl:if test="@type='scholia'"><xsl:apply-templates></xsl:apply-templates><hr/></xsl:if>
   </xsl:template>

   <xsl:template match="div3">
    <xsl:if test="(@type!='vet')"><div class="sch"><xsl:apply-templates  /><hr/></div></xsl:if>
    
   </xsl:template>

  
 <xsl:template match="p">
  <xsl:choose>
   <xsl:when test="name(parent)='refsDecl'"></xsl:when> 
   <xsl:when test="(../@type='argText') or (../@type='dramPersText')"><p class="arg"><xsl:apply-templates></xsl:apply-templates></p>
   </xsl:when>
   
   <xsl:otherwise><xsl:apply-templates></xsl:apply-templates></xsl:otherwise>
  </xsl:choose>
  
 </xsl:template>


<xsl:template match="head">
   <xsl:choose><xsl:when test="@type='outer'"><h2><xsl:value-of select="."></xsl:value-of ></h2></xsl:when>
      <xsl:otherwise><h3>Arg. <xsl:value-of select="../../@n"></xsl:value-of>: 
      <xsl:value-of select="."></xsl:value-of></h3></xsl:otherwise></xsl:choose>
</xsl:template>

 <xsl:template match="s">
  <xsl:choose><xsl:when test="@type='default'"><span class="sentNo"><sup><xsl:value-of
   select="@n"></xsl:value-of></sup></span><xsl:apply-templates></xsl:apply-templates>&#160;</xsl:when>
   <xsl:when test="@type='verseFinal'"><span class="sentNo"><sup><xsl:value-of
    select="@n"></xsl:value-of></sup></span><xsl:apply-templates></xsl:apply-templates><br/></xsl:when>
   <xsl:otherwise><span class="sentNo"><sup><xsl:value-of
    select="@n"></xsl:value-of></sup></span><xsl:apply-templates></xsl:apply-templates><br/>&#160;&#160;&#160;&#160;&#160;</xsl:otherwise></xsl:choose>
  
 </xsl:template>
 
 <xsl:template match="title" />
 <xsl:template match="author" />
 <xsl:template match="date" />
 <xsl:template match="sourceDesc" />
 <xsl:template match="refsDecl" />
 <xsl:template match="metrDecl" />
 <xsl:template match="metSym" />
 <xsl:template match="language" />  

</xsl:stylesheet>

