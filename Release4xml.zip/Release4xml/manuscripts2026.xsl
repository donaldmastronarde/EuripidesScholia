<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="2.0"
 xmlns:xs="http://www.w3.org/2001/XMLSchema"
 
 
 exclude-result-prefixes="xs">
 <xsl:output method="html" encoding="utf-8" version="5.0"
  />
 
 
 
 <xsl:template match="MSlist">
  <html lang="en">
   <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
     <title>Euripides Scholia: Manuscripts</title>
     
      <link rel="stylesheet" href="EurSchSite2026.css" type="text/css" />
   </head>
   <body>
    <div class="outerbackground"><div class="centered"><div class="banner"><table class="banner"><tr><td class="bannerImage"><a
     href="index.html"><img src="EurSchicon64x64.jpg" height="64" width="64" alt="icon Euripides
      Scholia with link to home page" /></a></td><td class="bannerTitle"><p class="bannerTitle">Euripides Scholia<br /><span class="subtitle">An Open-Access Online Edition</span></p></td></tr></table>
     
     <nav><p class="navig">&#160;&#160;&#160;<a href="EurSch2026_About.html"
      >About</a>&#160;&#160;&#160;|&#160;&#160;&#160;<a
       href="EurSch2026_Preface.html">Preface</a>&#160;&#160;&#160;|&#160;&#160;&#160;<a
        href="EurSch2026_Manuscripts.html">The
           Manuscripts</a>&#160;&#160;&#160;|&#160;&#160;&#160;<a href="Edition/OrestesScholia_all.html" target="_blank">Edition (Sch. Or.)</a>&#160;&#160;&#160;|&#160;&#160;&#160;<a href="Edition/PhoenScholia_all.html" target="_blank">Edition (Sch. Ph.)</a>&#160;&#160;&#160;|&#160;&#160;&#160;<a
          href="EurSch2026_Bibliography.html">Bibliography</a>&#160;&#160;&#160;|&#160;&#160;&#160;<a href="EurSch2026_Abbreviations.html">Abbreviations</a></p></nav></div>
    <h1 class="pageTitle">Manuscripts with Scholia on Euripides</h1>
    
    <p>See also the <a href="EurSch2026_SiglaTable.html">Sigla Table</a> for Euripidean manuscripts,
     which also contains the sigla for several dozen Euripidean manuscripts not described here.
     Note, however, that neither the present page nor the Sigla Table contains all the manuscripts
     of Euripides containing scholia, since many copies later than 1350 are not included.</p>
     <p>URLs rechecked in April 2025. Note that images at the British Library continue to be
      unavailable because of the cyberattack of October 2023. Unfortunately, there is no forecast of
      when particular manuscripts will be back online.</p>
      <p>For manuscripts of the Biblioteca Medicea Laurenziana, the old interface (which allows
       saving images) is available at <a class="imageURL" href="http://teca.bmlonline.it/TecaRicerca/index.jsp"
        target="_blank">http://teca.bmlonline.it/TecaRicerca/index.jsp<image src="linkIcon16x16.png" height="12" width="12" alt="small arrow indicating link, opening in a new window"></image></a>.</p>
     
     <p>Click on a siglum to go to the description:</p>
     <nav><p class="block12on14"> <a class="siglaLink" href="#ms006">A</a>
      &#160;<a      class="siglaLink" href="#ms007">Aa</a>
      &#160;<a  class="siglaLink" href="#ms007">Ab</a>
      &#160;<a       class="siglaLink" href="#ms058">Ad</a>
      &#160;<a  class="siglaLink"        href="#ms056">Af</a>
      &#160;<a  class="siglaLink" href="#ms009">At</a>
      &#160;<a          class="siglaLink" href="#ms003">B</a> 
      &#160;<a class="siglaLink" href="#ms098">Br</a>
      &#160;<a  class="siglaLink"          href="#ms010">C</a>
      &#160;<a  class="siglaLink" href="#ms011">Cr</a>
      &#160;<a            class="siglaLink" href="#ms059">D</a>
      &#160;<a  class="siglaLink"            href="#ms094">Dr</a>
      &#160;<a  class="siglaLink" href="#ms012">F</a>
      &#160;<a              class="siglaLink" href="#ms060">Fp</a>
      &#160;<a  class="siglaLink"              href="#ms013">G</a>
      &#160;<a class="siglaLink" href="#ms095">gB</a>
      &#160;<a  class="siglaLink" href="#ms040">Gr</a>&#160;<a 
               class="siglaLink" href="#ms046">Gu</a>&#160;<a 
                class="siglaLink" href="#ms001">H</a>&#160;<a 
                 class="siglaLink" href="#ms061">Hl</a>&#160;<a 
                  class="siglaLink" href="#ms027">Hn</a>&#160;<a 
                   class="siglaLink" href="#ms062">J</a>&#160;<a 
                    class="siglaLink" href="#ms014">K</a>&#160;<a 
                     class="siglaLink" href="#ms015">L</a>&#160;<a 
                      class="siglaLink" href="#ms063">La</a>&#160;<a 
                       class="siglaLink" href="#ms064">Lb</a>&#160;<a 
                        class="siglaLink" href="#ms065">Le</a>&#160;<a 
                         class="siglaLink" href="#ms066">Lp</a>
      &#160;<a class="siglaLink" href="#ms067">Lr</a>
      &#160;<a class="siglaLink" href="#ms068">Lw</a>
      &#160;<a class="siglaLink" href="#ms002">M</a>
      &#160;<a class="siglaLink" href="#ms069">Mb</a>
      &#160;<a class="siglaLink" href="#ms099">Mc</a>
       &#160;<a class="siglaLink" href="#ms104">Me</a>
       &#160;<a class="siglaLink" href="#ms070">Ml</a>
      &#160;<a class="siglaLink" href="#ms016">Mn</a>
      &#160;<a class="siglaLink" href="#ms101">Mp</a>
      &#160;<a class="siglaLink" href="#ms017">Mt</a>
      &#160;<a class="siglaLink" href="#ms071">Mu</a>
      &#160;<a class="siglaLink" href="#ms054">N</a>
      &#160;<a class="siglaLink" href="#ms055">Ne</a>
      &#160;<a class="siglaLink" href="#ms004">O</a>
      &#160;<a class="siglaLink" href="#ms018">Ox</a>
      &#160;<a class="siglaLink" href="#ms019">P</a>
      &#160;<a class="siglaLink" href="#ms072">Pa</a>
      &#160;<a class="siglaLink" href="#ms073">Pb</a>
      &#160;<a class="siglaLink" href="#ms020">Pc</a>
      &#160;<a class="siglaLink" href="#ms074">Pg</a>
      &#160;<a class="siglaLink" href="#ms075">Ph</a>
      &#160;<a class="siglaLink" href="#ms076">Pk</a>
      &#160;<a class="siglaLink" href="#ms077">Pl</a>
      &#160;<a class="siglaLink" href="#ms078">Pp</a>
      &#160;<a class="siglaLink" href="#ms021">Pr</a>
      &#160;<a class="siglaLink" href="#ms093">P.Oslo</a>
      &#160;<a class="siglaLink" href="#ms092">P.Würzb.</a>
      &#160;<a class="siglaLink" href="#ms022">Q</a>
      &#160;<a class="siglaLink" href="#ms023">R</a>
      &#160;<a class="siglaLink" href="#ms024">Rf</a>
      &#160;<a class="siglaLink" href="#ms025">Rv</a>
      &#160;<a class="siglaLink" href="#ms026">Rw</a>
      &#160;<a class="siglaLink" href="#ms079">Ry</a>
      &#160;<a class="siglaLink" href="#ms028">S</a>
      &#160;<a class="siglaLink" href="#ms029">Sa</a>
      &#160;<a class="siglaLink" href="#ms053">Sb</a>
      &#160;<a class="siglaLink" href="#ms048">T</a>
      &#160;<a class="siglaLink" href="#ms049">Ta</a>
      &#160;<a class="siglaLink" href="#ms097">Tb</a>
      &#160;<a class="siglaLink" href="#ms103">Tc</a>
      &#160;<a class="siglaLink" href="#ms080">Th</a>
      &#160;<a class="siglaLink" href="#ms102">Tu</a>
      &#160;<a class="siglaLink" href="#ms081">U</a>
      &#160;<a class="siglaLink" href="#ms005">V</a>
      &#160;<a class="siglaLink" href="#ms082">Va</a>
      &#160;<a class="siglaLink" href="#ms030">Vd</a>
      &#160;<a class="siglaLink" href="#ms100">Vn</a>
      &#160;<a class="siglaLink" href="#ms031">Vo</a>
      &#160;<a class="siglaLink" href="#ms032">Vr</a>
      &#160;<a class="siglaLink" href="#ms033">W</a>
      &#160;<a class="siglaLink" href="#ms034">X</a>
      &#160;<a class="siglaLink" href="#ms035">Xa</a>
      &#160;<a class="siglaLink" href="#ms036">Xb</a>
      &#160;<a class="siglaLink" href="#ms083">Xc</a>
      &#160;<a class="siglaLink" href="#ms084">Xd</a>
      &#160;<a class="siglaLink" href="#ms085">Xe</a>
      &#160;<a class="siglaLink" href="#ms086">Xf</a>
      &#160;<a class="siglaLink" href="#ms087">Xg</a>
      &#160;<a class="siglaLink" href="#ms088">Xh</a>
       &#160;<a class="siglaLink" href="#ms105">Xj</a>
       &#160;<a class="siglaLink" href="#ms089">Xm</a>
      &#160;<a class="siglaLink" href="#ms090">Xn</a>
      &#160;<a class="siglaLink" href="#ms037">Xo</a>
      &#160;<a class="siglaLink" href="#ms038">Y</a>
      &#160;<a class="siglaLink" href="#ms039">Yf</a>
      &#160;<a class="siglaLink" href="#ms091">Yn</a>
      &#160;<a class="siglaLink" href="#ms051">Yv</a>
      &#160;<a class="siglaLink" href="#ms041">Z</a>
      &#160;<a class="siglaLink" href="#ms042">Za</a>
      &#160;<a class="siglaLink" href="#ms043">Zb</a>
      &#160;<a class="siglaLink" href="#ms057">Zc</a>
      &#160;<a class="siglaLink" href="#ms044">Zd</a>
      &#160;<a class="siglaLink" href="#ms047">Zl</a>
      &#160;<a class="siglaLink" href="#ms045">Zm</a>
      &#160;<a class="siglaLink" href="#ms050">Zu</a>
      &#160;<a class="siglaLink" href="#ms052">Zv</a>
      &#160;<a class="siglaLink" href="#ms096">Zx</a></p></nav>
     
     
    <xsl:for-each-group select="//manuscript" group-by="@type">
     <hr/><h2><!--<xsl:value-of select="current-grouping-key()"></xsl:value-of>-->
      <xsl:if test="@type eq
       'earlyFrag'">Fragments of bookrolls or codices earlier than 800 CE</xsl:if>
      <xsl:if test="@type eq
      'pre1250'">Manuscripts written before 1250</xsl:if>
      <xsl:if test="@type eq
       'post1250'">Manuscripts written after 1250</xsl:if>
      <xsl:if test="@type eq
       'mosch'">Manuscripts with Moschopulean scholia</xsl:if>
      <xsl:if test="@type eq
       'thom'">Manuscripts with Thoman scholia</xsl:if>
      <xsl:if test="@type eq
       'tricl'">Manuscripts with Triclinian scholia</xsl:if>
      <xsl:if test="@type eq
       'miscLater'">Miscellaneous later manuscripts with scholia</xsl:if>
     </h2><hr/>
     <xsl:for-each select = "current-group()"><xsl:apply-templates></xsl:apply-templates><hr/></xsl:for-each>
    </xsl:for-each-group>
    <hr></hr>
     <p class="license"><a href="EurSch2026_About.html#license"><img width="45" height="16"
      alt="icon Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License with
      link" style="border-width:0" src="by-nc-sa.png" />&#160;&#160;CC License details</a>.</p>
     <p class="license">Feedback and corrigenda are welcome. Please use the Contact link in the footer.</p>
     
     <p class="footer">&#169; 2020, 2023 <a href="http://ucbclassics.dreamhosters.com/djm/"
      target="_parent">Donald J. Mastronarde</a><br></br><a 
       href="EurSch2026_About.html#contact">Contact</a></p><p>&#160;</p>
     
    </div></div>
    
   </body>
  </html>
 </xsl:template><!-- <xsl:template match="manuscript">

  <xsl:apply-templates/>
  <hr/>
 </xsl:template>
-->


 <xsl:template match="siglum">
  <!--<xsl:variable name="url" as="xs:string"
   select="concat('EurSch2026_manuscripts.html#',../@xml:id)"></xsl:variable>-->
  <!--<xsl:message><xsl:value-of select="$url"></xsl:value-of></xsl:message>-->
  <a><xsl:attribute name="class">siglum</xsl:attribute><xsl:attribute
   name="id">
   <xsl:value-of select="../@xml:id"></xsl:value-of>
  </xsl:attribute></a> <p class="siglum">
   <span class="label">SIGLUM: </span>
   <span class="siglum">
    <xsl:apply-templates/>
   </span><!--&#160;&#160;
   <span class="label">GROUP: </span>
   <span class="groupType">
    <xsl:value-of select="../@type"/>&#160;&#160;&#160;<xsl:value-of
     select="../@secondType"/>&#160;&#160;&#160;<xsl:value-of select="../@thirdType"/>
   </span>-->
  </p>
 </xsl:template>

 <xsl:template match="otherSigla">
  <p class="general">
   <span class="label">PREVIOUS OR OTHER SIGLA: </span>
   <xsl:apply-templates/>
  </p>
 </xsl:template>

 <xsl:template match="city">
  <p class="general">
   <span class="label">CITY: </span>
   <xsl:apply-templates/>
  </p>
 </xsl:template>
 <xsl:template match="collection">
  <p class="general">
   <span class="label">COLLECTION: </span>
   <xsl:apply-templates/>
  </p>
 </xsl:template>
 <xsl:template match="shelfmark">
  <p class="general">
   <span class="label">SHELFMARK: </span>
   <xsl:apply-templates/>
  </p>
 </xsl:template>
 <xsl:template match="date">
  <p class="general">
   <span class="label">DATE: </span>
   <xsl:apply-templates/>
  </p>
 </xsl:template>
 <xsl:template match="diktyon">
  <p class="general">
   <span class="label">NUMÉRO DIKTYON: </span>
   <xsl:apply-templates/>
  </p>
 </xsl:template>
 <xsl:template match="catalogue">
  <p class="general">
   <span class="label">CATALOGUE (later than Turyn 1957): </span>
   <xsl:apply-templates/>
  </p>
 </xsl:template>
 
 
 
 <xsl:template match="paginationContents">
  <p class="general">
   <span class="label">EURIPIDEAN CONTENTS: </span>
   <xsl:apply-templates/>
  </p>
 </xsl:template>
 <xsl:template match="typeAndFormat">
  <p class="general">
   <span class="label">TYPE AND FORMAT: </span></p>
   <xsl:apply-templates/>
  
 </xsl:template>
 <xsl:template match="hands">
  <p class="general">
   <span class="label">HANDS: </span></p>
   <xsl:apply-templates/>
  
 </xsl:template>
 
 
 <xsl:template match="imagesUsed">
  <p class="general">
   <span class="label">IMAGES USED: </span>
   <xsl:apply-templates/>
  </p>
 </xsl:template>
 <xsl:template match="onLineImages">
  <p class="general">
   <span class="label">ONLINE IMAGES: </span>
   <xsl:apply-templates/>
  </p>
 </xsl:template>

 <xsl:template match="link">
  <a  class="imageURL">
   <xsl:attribute name="href">
    <xsl:value-of select="linkURL"/>
   </xsl:attribute>
   <xsl:attribute name="target">_blank</xsl:attribute>
   
   <xsl:value-of select="linkName"/><image src="linkIcon16x16.png" height="12" width="12" alt="small arrow indicating link, opening in new window"/>
  </a>

 </xsl:template>

 <xsl:template match="xrefLink">
  <a  class="xrefLink">
   <xsl:attribute name="href">
    <xsl:value-of select="linkURL"/>
   </xsl:attribute>
   <xsl:attribute name="target">_blank</xsl:attribute>
   
   <xsl:value-of select="linkName"/>
  </a>
  
 </xsl:template>
 
 <xsl:template match="bibliography">
  <p class="general">
   <span class="label">SELECT BIBLIOGRAPHY: </span>
   <xsl:apply-templates/>
  </p>
 </xsl:template>
 

 <xsl:template match="bibliography1">
  <p class="general">
   <span class="label">old SELECT BIBLIOGRAPHY: </span>
   <xsl:apply-templates/>
  </p>
 </xsl:template>

 <xsl:template match="bibliography2">
  <p class="general">
   <span class="label">FURTHER BIBLIOGRAPHY: </span>
   <xsl:apply-templates/>
  </p>
 </xsl:template>

 <xsl:template match="biblioShort">
  <xsl:variable name="url" as="xs:string" select="concat('EurSch2026_Bibliography.html#',@xml:id)"></xsl:variable>
  <!--<xsl:message><xsl:value-of select="$url"></xsl:value-of></xsl:message>-->
  <a><xsl:attribute name="target">_blank</xsl:attribute><xsl:attribute name="class">biblio</xsl:attribute><xsl:attribute
   name="href">
    <xsl:value-of select="$url"></xsl:value-of>
  </xsl:attribute><xsl:apply-templates></xsl:apply-templates></a>
   
 </xsl:template>
 

 <xsl:template match="discussion">
  <p class="general">
   <span class="label">DISCUSSION: </span></p> 
  <xsl:apply-templates/>  
 

 </xsl:template>

 <xsl:template match="p">
  <xsl:apply-templates/>

 </xsl:template>

 <xsl:template match="seg">
  <xsl:choose>

   <xsl:when test="(@type='discuss')">
    <p class="discuss">
     <xsl:apply-templates/>
    </p>
   </xsl:when>
   <xsl:when test="(@type='witMod')">
    <sup>
     <xsl:apply-templates/>
    </sup>
   </xsl:when>
   <xsl:otherwise>
    <p class="general">
     <xsl:apply-templates/>
    </p>
   </xsl:otherwise>
  </xsl:choose>

 </xsl:template>

</xsl:stylesheet>
