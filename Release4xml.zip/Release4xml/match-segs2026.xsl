<xsl:stylesheet version="2.0"
     xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
     xmlns:tei="http://www.tei-c.org/ns/1.0"
     xmlns:xs="http://www.w3.org/2001/XMLSchema">
   
   <xsl:template match="seg">
      <xsl:variable name="itemSeparator"> &#160;&#160;&#160;| &#160;&#160;&#160;</xsl:variable>
      <xsl:variable name="longSeparator"> &#160;&#160;&#160;&#160;&#160;&#160;</xsl:variable>
  <xsl:choose>
     <xsl:when test="@type='witnesses'">
        <span class="wit">&#160;&#8212;<xsl:apply-templates  /></span>
     </xsl:when>
     <xsl:when test="(@type='lemma') and (@subtype='inMS')">
        <span class="lemma"><xsl:value-of select="."/>:&#160;</span>
     </xsl:when>
     <xsl:when test="(@type='lemma') and (@subtype='added')">
        <span class="lemma">⟨<xsl:value-of select="."/>⟩:&#160;</span>
     </xsl:when>
     <xsl:when test="@type='prevEd'"><xsl:apply-templates></xsl:apply-templates>
     </xsl:when>
      <xsl:when test="@type='longTrans'"><xsl:apply-templates></xsl:apply-templates><br/>&#160;&#160;&#160;
      </xsl:when>
      
     <xsl:when test="@type='witMod'"><span class="witMod"><sup><xsl:value-of select="."/></sup></span>
     </xsl:when>
     <xsl:when test="@type='appItem'">
       <xsl:apply-templates  />
        <xsl:choose><xsl:when test="not(position()=last())">
           <xsl:value-of select="$itemSeparator"/></xsl:when>
           <xsl:otherwise>&#160;&#160;&#160;</xsl:otherwise>
        </xsl:choose>
            </xsl:when>
     <xsl:when test="@type='pos'">
        <span class="label">POSITION:</span>&#160;<xsl:apply-templates  /><xsl:value-of select="$longSeparator"/>
     </xsl:when>
      <xsl:when test="@type='lemmaNote'">
       <span class="label">LEMMA:</span>&#160;<xsl:apply-templates  />        
         <xsl:value-of select="$longSeparator"/>
     </xsl:when>
     <xsl:when test="@type='refSymb'">
        <span class="label">REF.&#160;SYMBOL:</span>&#160;<xsl:apply-templates  /><xsl:value-of select="$longSeparator"/>
     </xsl:when>
     <xsl:when test="@type='orthogr'">
        <xsl:apply-templates  />
        <xsl:choose><xsl:when test="not(position()=last())">
           <xsl:value-of select="$itemSeparator"/></xsl:when>
           <xsl:otherwise>&#160;&#160;&#160;</xsl:otherwise>
        </xsl:choose>
     </xsl:when>
     <xsl:when test="@type='other'">
        <xsl:apply-templates  />
        <xsl:choose><xsl:when test="not(position()=last())">
           <xsl:value-of select="$itemSeparator"/></xsl:when>
           <xsl:otherwise>&#160;&#160;&#160;</xsl:otherwise>
        </xsl:choose>
     </xsl:when>
     <xsl:when test="@type='metrScheme'">
        <xsl:apply-templates></xsl:apply-templates><br/> 
     </xsl:when>
     <xsl:when test="@type='triColon'">
        <xsl:apply-templates></xsl:apply-templates><br/></xsl:when>
   <xsl:when test="@type='keywds'"><xsl:apply-templates  />
    <xsl:choose><xsl:when test="not(position()=last())">
     <xsl:value-of select="$itemSeparator"/></xsl:when>
     <xsl:otherwise>&#160;&#160;&#160;</xsl:otherwise>
    </xsl:choose></xsl:when>
  </xsl:choose>
     
  </xsl:template>
</xsl:stylesheet>