<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:eur="http://classics.dreamhosters.com/djm"
    
    xmlns:xs="http://www.w3.org/2001/XMLSchema"
    exclude-result-prefixes="xs"
    version="2.0">
    
    <xsl:function  name="eur:getBiblURL" as="xs:string">
        <xsl:param name="bibl"></xsl:param>
        <xsl:variable name="CWKBbase" as="xs:string">http://cwkb.org/resolver?ctx_ver=Z39.88-2004&amp;rft_val_fmt=info:ofi/fmt:kev:mtx:canonical_cit&amp;rft.au=</xsl:variable>
        <xsl:variable name="refAuth" as="xs:string" ><xsl:value-of
            select="$bibl/refAuthor"></xsl:value-of></xsl:variable>
        <xsl:variable name="refTitle" as="xs:string"><xsl:value-of  select="$bibl/refTitle"/></xsl:variable>
        <xsl:variable name="ref" as="xs:string"><xsl:value-of select="$bibl/ref"/></xsl:variable>
        <xsl:variable name="biblURL" as="xs:string" select="concat($CWKBbase,$refAuth,'&amp;rft.title=',$refTitle,'&amp;rft.slevel1=',$ref)"></xsl:variable>
        <xsl:copy-of select="$biblURL"></xsl:copy-of>
    </xsl:function>
    
    
    
    <xsl:template match="bibl">[<a><xsl:attribute name="target">_blank</xsl:attribute><xsl:attribute
                name="href">
                <xsl:value-of select="eur:getBiblURL(/bibl)"></xsl:value-of>
            </xsl:attribute><xsl:apply-templates></xsl:apply-templates></a>]</xsl:template> 
    
    <xsl:template
        match="refAuthor">
        
        
        
        <xsl:choose><xsl:when test="(../@type='anc') or (../@type='modern')"><xsl:apply-templates></xsl:apply-templates>&#160;</xsl:when></xsl:choose></xsl:template> 
    
    <xsl:template
        match="refTitle"><xsl:choose><xsl:when test="(../@type='anc') or (../@type='modern') or
            (../@type='otherEur')">
            
            <i><xsl:apply-templates></xsl:apply-templates></i>&#160;</xsl:when></xsl:choose></xsl:template> 
    
    <xsl:template match="ref"><xsl:apply-templates></xsl:apply-templates></xsl:template>
    
    <xsl:template match="biblioShort">
        <xsl:variable name="url" as="xs:string" select="concat('../EurSch2025_Bibliography.html#',@xml:id)"></xsl:variable>
        <!--<xsl:message><xsl:value-of select="$url"></xsl:value-of></xsl:message>-->
        <a><xsl:attribute name="class">biblio</xsl:attribute><xsl:attribute name="target">_blank</xsl:attribute><xsl:attribute
            name="href">
            <xsl:value-of select="$url"></xsl:value-of>
        </xsl:attribute><xsl:apply-templates></xsl:apply-templates></a>
        
    </xsl:template>
    
    
</xsl:stylesheet>