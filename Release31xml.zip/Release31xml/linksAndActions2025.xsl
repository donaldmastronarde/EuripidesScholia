<xsl:stylesheet version="2.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    ><xsl:template match="div1">
        <html><head>
            <link rel="stylesheet" title="all" type="text/css" href="scholiaEur1111display.css" />
            <link rel="alternate stylesheet" title="schTransApp" type="text/css" href="scholiaEur1110display.css" />
        <link rel="alternate stylesheet" title="schTrans" type="text/css" href="scholiaEur1100display.css" />
        <link rel="alternate stylesheet" title="schApp" type="text/css" href="scholiaEur1010display.css" />
        <link rel="alternate stylesheet" title="sch" type="text/css" href="scholiaEur1000display.css" />
        <script src="selectActions2025.js" type="text/javascript"></script>
        <link rel="alternate stylesheet" title="allprint" type="text/css" href="scholiaEurFullprint.css" />
        <title>Euripides
            Scholia: <xsl:value-of
                select="@xml:id"></xsl:value-of></title></head>
        <body>
        <div class="outerbackground"><div class="centered">
            <div class="banner"><table class="banner"><tr><td class="bannerImage"><a
                href="../index.html" target="_blank"><img
                src="../EurSchicon64x64.jpg" height="64" width="64" alt="icon for Euripides Scholia"
            /></a></td><td class="bannerTitle"><p class="bannerTitle">Euripides Scholia<br /><span class="subtitle">An Open-Access Online Edition</span></p></td></tr></table>
                
                <p class="navig">&#160;&#160;&#160;<a href="../EurSch2025_About.html" target="_blank"
                    >About</a>&#160;&#160;&#160;&#160;|&#160;&#160;&#160;&#160;<a
                        href="../EurSch2025_Preface.html" target="_blank">Preface</a>&#160;&#160;&#160;&#160;|&#160;&#160;&#160;&#160;<a
                            href="../EurSch2025_Manuscripts.html" target="_blank">The
                            Manuscripts</a>&#160;&#160;&#160;&#160;|&#160;&#160;&#160;&#160;<a
                                href="OrestesScholia_all.html" target="_blank">Edition</a>&#160;&#160;&#160;&#160;|&#160;&#160;&#160;&#160;<a
                                    href="../EurSch2025_Bibliography.html" target="_blank">Bibliography</a>&#160;&#160;&#160;&#160;|&#160;&#160;&#160;&#160;<a
                                        href="../EurSch2025_Keywords.html" target="_blank">Keywords</a>&#160;&#160;&#160;&#160;|&#160;&#160;&#160;&#160;<a
                                            href="../EurSch2025_Abbreviations.html" target="_blank">Abbreviations</a></p>
            
                <form class="filter" name="form">Set to display:&#160;&#160;<select name="defineSet" onChange="setSchFile(this.form)">
                    <option value="all">All scholia</option>
                    <option value="vet">Vetera</option>
                    <option value="rec">Recentiora and later</option>
                    <option value="MTT">Mosch., Thom., and Tri.</option>
                    <option value="mosch">Moschopulean (with Planudean)</option>
                    <option value="thom">Thoman</option>
                    <option value="tri">Triclinian</option>
                    <option value="exeg">Exegetic only</option>
                    <option value="noGloss">Scholia (no glosses)</option>
                    <option value="gloss">Glosses only</option>
                    <option value="treat">Triclinian treatises</option>
                    
                </select>
                    &#160;&#160;&#160;&#160;&#160;
                    Details to display:&#160;&#160;
                    <select name="defineDisplay" onChange="setDisplay(this.form)">
                        <option value="all">All elements</option>
                        <option value="schTransApp">Scholia text, transl., main app. crit.</option>
                        <option value="schTrans">Scholia text, translation</option>
                        <option value="schApp">Scholia text, main app. crit.</option>
                        <option value="sch">Scholia text only</option>
                        <option value="allprint">All elements (B&amp;W for print)</option>
                    </select>
                </form></div>
            
            <h2><xsl:value-of
                select="@xml:id"></xsl:value-of></h2><hr/>
            <xsl:apply-templates  />
        
            <hr></hr>
            <p class="license"><a href="../EurSch2025_About.html#license"><img width="45" height="16"
                alt="Creative Commons License icon" style="border-width:0" src="../by-nc-sa.png" />&#160;&#160;CC License details</a>.</p>
            <p class="indented16">Feedback and corrigenda are welcome. Please use the Contact link in the footer.</p>
            
            <p class="footer">&#169; 2020, 2023, 2025 <a href="http://ucbclassics.dreamhosters.com/djm/"
                target="_parent">Donald J. Mastronarde</a><br></br><a href="../EurSch2025_About.html#contact">Contact</a></p><p>&#160;</p>
            
        </div></div>
        </body></html>
</xsl:template>
</xsl:stylesheet>