<xsl:stylesheet version="2.0"
     xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

   <xsl:output method="html" encoding="utf-8" version="5.0"></xsl:output>
   <xsl:include href="match-div4s2025.xsl"/>
   
   <xsl:include href="match-segs2025.xsl"/>
   <xsl:include href="match-bibl2025.xsl"/>
   

<xsl:template match="body">
<xsl:apply-templates></xsl:apply-templates>
</xsl:template>
   <xsl:include href="linksAndActions2025.xsl"/>
   

   <xsl:template match="div2"><xsl:apply-templates></xsl:apply-templates><hr/>
   </xsl:template>

   <xsl:template match="div3">
      <xsl:choose>
         
       <xsl:when test="(@type='otherConcomitantText') or (@type='epitome') or (@type='misc') or (@type='AristByz') or
            (@type='argThom') or (@type='dramatisPersonae')"><div class="arg"><xsl:apply-templates  /><hr/></div></xsl:when>
         <xsl:otherwise><div class="sch"><xsl:apply-templates  /><hr/></div></xsl:otherwise>
      </xsl:choose>
   </xsl:template>

   
<xsl:template match="p">
   <xsl:choose>
      <xsl:when test="name(parent)='refsDecl'"></xsl:when> 
    <xsl:when test="(../@type='otherText') or(../@type='argText') or (../@type='dramPersText')"><p class="arg"><xsl:apply-templates></xsl:apply-templates></p>
      </xsl:when>
      
     <xsl:otherwise><xsl:apply-templates></xsl:apply-templates></xsl:otherwise>
   </xsl:choose>
   
</xsl:template>


<xsl:template match="head">
   <xsl:choose><xsl:when test="@type='outer'"><h3><xsl:value-of select="."></xsl:value-of ></h3></xsl:when>
      <xsl:otherwise><h4>Text <xsl:value-of select="../../@n"></xsl:value-of>: 
      <xsl:value-of select="."></xsl:value-of></h4></xsl:otherwise></xsl:choose>
</xsl:template>

<xsl:template match="s">
   <xsl:choose><xsl:when test="../../@type='metrScheme'"><span class="sentNo"><sup><xsl:value-of
      select="@n"></xsl:value-of></sup></span><xsl:apply-templates></xsl:apply-templates></xsl:when
      ><xsl:otherwise><span class="sentNo"><sup><xsl:value-of
         select="@n"></xsl:value-of></sup></span><xsl:value-of
            select="."></xsl:value-of>&#160;</xsl:otherwise></xsl:choose>
</xsl:template>
   
  
   <xsl:template match="title" />
   <xsl:template match="author" />
   <xsl:template match="date" />
   <xsl:template match="sourceDesc" />
   <xsl:template match="refsDecl" />
   <xsl:template match="metrDecl" />
   <xsl:template match="metSym" />
   <xsl:template match="language" />
</xsl:stylesheet>

