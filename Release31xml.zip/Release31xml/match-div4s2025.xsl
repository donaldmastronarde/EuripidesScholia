
<xsl:stylesheet version="2.0"
     xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
     xmlns:eur="http://classics.dreamhosters.com/djm"
     xmlns:tei="http://www.tei-c.org/ns/1.0"
     xmlns:xs="http://www.w3.org/2001/XMLSchema">
   
 <xsl:function name="eur:generateNo" as="xs:string">
 <xsl:param name="schNo" as="xs:string"></xsl:param>
  <xsl:variable name="playName" select="substring($schNo, 1, 2)" as="xs:string"></xsl:variable>
  <xsl:variable name="lineNo" select="substring($schNo, 3, 4)" as="xs:string"></xsl:variable>
 
  
  <xsl:choose>
   <xsl:when test="substring($lineNo, 1, 3) = '000'"><xsl:variable name="lineNo"
    select="substring($lineNo, 4, 1)" as="xs:string"></xsl:variable><xsl:copy-of
     select="concat($playName, '. ', $lineNo)"></xsl:copy-of>
   </xsl:when>
   <xsl:when test="substring($lineNo, 1, 2) = '00'"><xsl:variable name="lineNo"
    select="substring($lineNo, 3, 2)" as="xs:string"></xsl:variable><xsl:copy-of select="concat($playName, '. ', $lineNo)"></xsl:copy-of>
   </xsl:when>
   <xsl:when test="substring($lineNo, 1, 1) = '0'"><xsl:variable name="lineNo"
    select="substring($lineNo, 2, 3)"  as="xs:string"></xsl:variable><xsl:copy-of select="concat($playName, '. ', $lineNo)"></xsl:copy-of>
   </xsl:when>
  <xsl:otherwise><xsl:copy-of select="concat($playName, '. ', $lineNo)"></xsl:copy-of></xsl:otherwise>
  </xsl:choose>
</xsl:function>

 <xsl:function name="eur:generateNoForURL" as="xs:string">
  <xsl:param name="schNo" as="xs:string"></xsl:param>
  
  <xsl:variable name="lineNoForURL" select="substring($schNo, 3, 4)" as="xs:string"></xsl:variable>
  
  
  <xsl:choose>
   <xsl:when test="substring($lineNoForURL, 1, 3) = '000'"><xsl:variable name="lineNoForURL"
    select="substring($lineNoForURL, 4, 1)" as="xs:string"></xsl:variable><xsl:copy-of select="$lineNoForURL"></xsl:copy-of>
   </xsl:when>
   <xsl:when test="substring($lineNoForURL, 1, 2) = '00'"><xsl:variable name="lineNoForURL"
    select="substring($lineNoForURL, 3, 2)" as="xs:string"></xsl:variable><xsl:copy-of select="$lineNoForURL"></xsl:copy-of>
   </xsl:when>
   <xsl:when test="substring($lineNoForURL, 1, 1) = '0'"><xsl:variable name="lineNoForURL"
    select="substring($lineNoForURL, 2, 3)"  as="xs:string"></xsl:variable><xsl:copy-of select="$lineNoForURL"></xsl:copy-of>
   </xsl:when> 
   <xsl:otherwise><xsl:copy-of select="$lineNoForURL"></xsl:copy-of></xsl:otherwise>
  </xsl:choose>
 </xsl:function>
  
 <xsl:function name="eur:generateSubNo" as="xs:string">
 <xsl:param name="subNo" as="xs:string"></xsl:param>
  <xsl:variable name="lineSubNo" select="substring($subNo, 8,3)" as="xs:string"></xsl:variable>
  <xsl:value-of select="$lineSubNo"></xsl:value-of>
 </xsl:function>
 
 <xsl:template match="div4">
      <xsl:choose>
       <xsl:when test="(@type='argText') or (@type='dramPersText') or (@type='otherText')"><a> <xsl:attribute name="id"><xsl:value-of select="../@xml:id"/></xsl:attribute></a><xsl:apply-templates></xsl:apply-templates></xsl:when>
         
         <xsl:when test="@type='schText'">
          
          <p class="sch"><b><xsl:value-of select="eur:generateNo(../@xml:id)"></xsl:value-of>.<span
       class="schType"><xsl:value-of select="eur:generateSubNo(../@xml:id)"></xsl:value-of></span> 
       <xsl:if test="exists(../@n)"><xsl:value-of select="concat(' (', ../@n, ')')"></xsl:value-of></xsl:if></b>
           <a> <xsl:attribute name="id"><xsl:value-of select="../@xml:id"/></xsl:attribute></a>
           <span class="schType">
               (<xsl:value-of select="../@type" />&#160;<xsl:value-of select="../@subtype"/>)&#160;</span>
         <xsl:apply-templates  /></p></xsl:when>
       
         <xsl:when test="@type='schTextMetrAna'">
          <table class="metrAna"><tr>
             <td class="triSch"><p class="sch"><b><xsl:value-of select="eur:generateNo(../@xml:id)"></xsl:value-of>.<span
               class="schType"><xsl:value-of select="eur:generateSubNo(../@xml:id)"></xsl:value-of></span> 
               <xsl:if test="exists(../@n)"><xsl:value-of select="concat(' (', ../@n, ')')"></xsl:value-of></xsl:if></b> <a> <xsl:attribute name="id"><xsl:value-of select="../@xml:id"/></xsl:attribute></a>
              <span class="schType">
                  (<xsl:value-of select="../@type" />&#160;<xsl:value-of select="../@subtype"/>)&#160;</span>
              <xsl:apply-templates></xsl:apply-templates></p></td>
               <td class="metrAna"><p class="metrAna"><xsl:apply-templates
                  select="../div4[2]/p"></xsl:apply-templates></p></td>
        </tr></table>
        </xsl:when>
         
         <xsl:when test="@type='appCrit'">
          <p class="app"><span class="label">APP. CRIT.:</span>&#160;&#160;<xsl:apply-templates  /></p></xsl:when>
         
       
       <xsl:when test="@type='lemmaPosNote'">
        <p class="lemmaPos"><xsl:apply-templates  /></p></xsl:when>
       
       <xsl:when test="@type='posNote'">
        <p class="lemmaPos"><xsl:apply-templates  /></p></xsl:when>
       
         <xsl:when test="@type='collNotes'">
          <p class="collNotes"><span class="label">COLLATION NOTES:</span>&#160;&#160;<xsl:apply-templates  /></p></xsl:when>
         
         <xsl:when test="@type='appCrit2'">
          <p class="appCrit2"><span class="label">APP. CRIT. 2:</span>&#160;&#160;<xsl:apply-templates  /></p></xsl:when>
         
         <xsl:when test="@type='engTrans'">
          <p class="engTrans"><span class="label">TRANSLATION:</span>&#160;&#160;<xsl:apply-templates  /></p></xsl:when>
       <xsl:when test="@type='commentSim'">
        <p class="comment"><span class="label">COMMENT:</span>&#160;&#160;<xsl:apply-templates  /></p></xsl:when>
       <xsl:when test="@type='previousEditions'">
        <p class="keywds"><span class="label">PREVIOUS EDITIONS:</span>&#160;&#160;<xsl:apply-templates  /></p></xsl:when>
       <xsl:when test="@type='keywords'">
        <p class="keywds"><span class="label">KEYWORDS:</span>&#160;&#160;<xsl:apply-templates  /></p></xsl:when>
      </xsl:choose>
   </xsl:template>
   
</xsl:stylesheet>