function setSchFile( x ) {
var setName = x.defineSet.options[x.defineSet.selectedIndex].value;
//alert(setName);
switch (setName)
{
case 'all':
location.href = "PhoenScholia_all.html";
break;
case 'vet':
location.href ="PhoenScholia_vet.html";
break;
case 'rec':
location.href ="PhoenScholia_rec.html";
break;
case 'MTT':
location.href ="PhoenScholia_MTT.html";
break;
case 'mosch':
location.href ="PhoenScholia_mosch.html";
break;
case 'thom':
location.href ="PhoenScholia_thom.html";
break;
case 'tri':
location.href ="PhoenScholia_tri.html";
break;
case 'exeg':
location.href ="PhoenScholia_exeg.html";
break;
case 'noGloss':
location.href ="PhoenScholia_noGloss.html";
break;
case 'gloss':
location.href ="PhoenScholia_glosses.html";
break;
case 'treat':
location.href ="OrestesScholia_treat.html";
break;
}
}

function setDisplay( x )
	{
	// You may use this script on your site free of charge provided
// you do not remove this notice or the URL below. Script from
// https://www.thesitewizard.com/javascripts/change-style-sheets.shtml
 //alert('setStyle called');
  var i, link_tag ;
css_title = x.defineDisplay.options[x.defineDisplay.selectedIndex].value;
//alert(css_title);
  for (i = 0, link_tag = document.getElementsByTagName("link") ;
        i < link_tag.length ; i++ ) {
    //alert(i);
    if ((link_tag[i].rel.indexOf( "stylesheet" ) != -1) &&
      link_tag[i].title) {
      link_tag[i].disabled = true ;
      if (link_tag[i].title == css_title) {
        link_tag[i].disabled = false ;
     	 	}
    	}
	}
}
